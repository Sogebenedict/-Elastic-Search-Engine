Sample plugin for elasticsearch
===========================

This project is a sample for elasticsearch plugin.
elasticsearch-plugin-archetype is created from this project.

